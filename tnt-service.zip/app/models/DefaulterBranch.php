<?php

/**
 * Created by PhpStorm.
 * User: ELACHI
 * Date: 6/27/2016
 * Time: 10:48 AM
 */
class DefaulterBranch extends Branch
{
    public function getSource()
    {
        return 'branch';
    }
}